/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#f0fdf9',
          100: '#ccfbf1',
          200: '#99f6e4',
          300: '#5eead4',
          400: '#2dd4bf',
          500: '#0e7c6b',
          600: '#0d685a',
          700: '#0f5249',
          800: '#11433d',
          900: '#173b3a',
          950: '#0a1d1d',
        },
        accent: {
          gold: '#f2b632',
          amber: '#d97706',
          coral: '#f43f5e',
        }
      },
      fontFamily: {
        sans: ['Inter', 'Segoe UI', 'system-ui', 'sans-serif'],
        mono: ['Fira Code', 'monospace'],
        serif: ['Georgia', 'serif'],
      },
    },
  },
  plugins: [],
}
